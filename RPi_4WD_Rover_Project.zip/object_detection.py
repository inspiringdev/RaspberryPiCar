
import cv2
net = cv2.dnn.readNetFromCaffe('deploy.prototxt', 'mobilenet_iter_73000.caffemodel')
CLASSES = ["background","aeroplane","bicycle","bird","boat","bottle","bus","car","cat","chair","cow","diningtable","dog","horse","motorbike","person","pottedplant","sheep","sofa","train","tvmonitor"]
def detect_objects():
 cap = cv2.VideoCapture(0)
 while True:
  r, f = cap.read(); h, w = f.shape[:2]
  blob = cv2.dnn.blobFromImage(cv2.resize(f, (300, 300)), 0.007843, (300, 300), 127.5)
  net.setInput(blob); d = net.forward()
  for i in range(d.shape[2]):
   conf = d[0, 0, i, 2]
   if conf > 0.5:
    idx = int(d[0, 0, i, 1]); box = d[0, 0, i, 3:7] * [w, h, w, h]
    (x1, y1, x2, y2) = box.astype("int"); l = CLASSES[idx]
    cv2.rectangle(f, (x1, y1), (x2, y2), (0, 255, 0), 2); cv2.putText(f, l, (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)
  cv2.imshow("Detection", f)
  if cv2.waitKey(1) & 0xFF == ord("q"): break
 cap.release(); cv2.destroyAllWindows()
