
import RPi.GPIO as GPIO, time
TRIG, ECHO = 23, 24
GPIO.setup(TRIG, GPIO.OUT)
GPIO.setup(ECHO, GPIO.IN)
def get_distance():
 GPIO.output(TRIG, True); time.sleep(0.00001); GPIO.output(TRIG, False)
 while GPIO.input(ECHO)==0: start = time.time()
 while GPIO.input(ECHO)==1: stop = time.time()
 return ((stop - start) * 34300) / 2
