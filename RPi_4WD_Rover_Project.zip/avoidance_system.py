
from motor_control import forward, stop
from ultrasonic_sensor import get_distance
def avoid():
 while True:
  d = get_distance()
  if d < 6: stop(); break
  else: forward()
