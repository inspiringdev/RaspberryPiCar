
import RPi.GPIO as GPIO
GPIO.setmode(GPIO.BCM)
pins = [17, 18, 27, 22]
for pin in pins: GPIO.setup(pin, GPIO.OUT)
def forward(): GPIO.output(17,1); GPIO.output(18,0); GPIO.output(27,1); GPIO.output(22,0)
def backward(): GPIO.output(17,0); GPIO.output(18,1); GPIO.output(27,0); GPIO.output(22,1)
def stop(): [GPIO.output(pin, 0) for pin in pins]
