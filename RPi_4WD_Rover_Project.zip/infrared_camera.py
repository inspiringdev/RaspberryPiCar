
import cv2
def start_camera():
 cap = cv2.VideoCapture(0)
 while True:
  r, f = cap.read()
  if r: cv2.imshow('IR', f)
  if cv2.waitKey(1) & 0xFF == ord('q'): break
 cap.release(); cv2.destroyAllWindows()
