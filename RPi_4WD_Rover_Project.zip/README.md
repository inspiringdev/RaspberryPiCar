
# Raspberry Pi 4B Smart 4WD Rover Project

## Overview
This project showcases a Raspberry Pi 4B-powered robotic 4WD vehicle capable of:
- Metal detection
- Obstacle avoidance
- Real-time object detection using OpenCV
- IR camera streaming
- Mobile-controlled navigation via WiFi/Bluetooth

## Features
- **Motor Control**: GPIO-based forward, backward, and stop functions
- **Ultrasonic Sensor**: Detects obstacles and stops the vehicle if <6cm
- **Metal Detection**: Uses analog SPI interface to detect underground metals
- **IR Camera**: Streams real-time visuals
- **OpenCV Object Detection**: Uses MobileNetSSD and pretrained weights
- **Multithreaded Execution**: All modules run concurrently

## Prerequisites
- Raspberry Pi OS (Raspbian)
- Python 3
- Thonny IDE
- `opencv-python`, `RPi.GPIO`, `spidev`

## Files
- `motor_control.py`: GPIO-based motor commands
- `ultrasonic_sensor.py`: Distance measurement
- `metal_detector.py`: Metal sensing module
- `infrared_camera.py`: Camera visual
- `object_detection.py`: AI-based object detection
- `avoidance_system.py`: Collision avoidance
- `main.py`: Combined execution of all modules

## Setup
```bash
pip install opencv-python RPi.GPIO spidev
```

## Run
```bash
python3 main.py
```

> Note: You must also place `deploy.prototxt` and `mobilenet_iter_73000.caffemodel` in the same directory for object detection to work.

## Author
Developed by Ubaid ur Rehman — 2nd Semester DLD Project, NUST
