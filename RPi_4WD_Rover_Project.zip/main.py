
from motor_control import forward, stop
from ultrasonic_sensor import get_distance
from metal_detector import read_metal
from avoidance_system import avoid
from object_detection import detect_objects
from infrared_camera import start_camera
import threading
def run():
 threading.Thread(target=avoid).start()
 threading.Thread(target=detect_objects).start()
 threading.Thread(target=start_camera).start()
run()
